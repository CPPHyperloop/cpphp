import struct
import socket
import sys
from multiprocessing import Process, Queue

SENDPORT = 10000 # 'udp' port
RECVPORT = 10001 # 'tcp' port
# it would probably be fine to use the same port for both since they are using different protocol
# but just to be safe

THISIP = '192.168.x.x' 
# please change it to ip address of this raspi before running it
# or else tcp won't work

PACKPATTERN = '<Lffffff'
# please change them according to types, number of and index of data being sent
# see link below for reference of format character
# https://docs.python.org/2/library/struct.html#format-characters
# note that arduino use non-standard size for data type, see below
# https://robotresearchlab.com/2016/11/14/variable-data-types/

guiip = [] 
# ip address of connected client (gui) in string
# ip address will be added when tcp connection is established the first time
# can be hard coded to send to known ip addresses
# e.g. ['192.168.1.123','192.168.1.7']
# best to hard code it for now as tcp may not yet work

# probably need to use a non repeating Set object instead of list/array to avoid duplication
# or a good old iteration before adding the ip address

def initguisend(queue): # 'main' of subprocess handling sending of telemetry over udp
    # send each data to all 'connected' client. 
    # Will send even if tcp connection of a client is lost. i.e. induvidualguicomm terminates
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    while True: 
        # send whenever there is new data got put into guisendqueue in code.py
        if not queue.empty():
            data = queue.get()
            if len(guiip) > 0:
                # send a copy to every ip address that was at one point connected
                for ip in guiip:
                    sock.sendto(struct.pack(PACKPATTERN, *data),(ip,SENDPORT))
                    # *data 'unpack' data into successive arguments of struct.pack
                    # necessary since struct.pack wants the values to be individual arguments
                    # i.e. instead of a single list being the second argument
                    # 1st element of list became second arg, 2nd element became 3rd arg, etc.
                    # e.g. data = [a,b,c]
                    # struct.pack(PACKPATTERN, data) == struct.pack(PACKPATTERN, [a,b,c])
                    # struct.pack(PACKPATTERN, *data) == struct.pack(PACKPATTERN, a, b, c)
                    
    # not closing socket. could be troubling.
    
def initguicomm(queue): # 'main' of subprocess handling establishment of tcp connection
    # only listen and accept tcp connection
    # actual data transmission is handled by indivudualguicomm
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = (THISIP, RECVPORT)
    sock.bind(server_address)
    sock.listen()
    while True:
        connection, client_address = sock.accept() # accept() blocks this subprocess if there is no pending client
        # variable 'connection' is a socket object returned by accept() representing connection to client accepted
        guiip.append(client_address)  # add accepted client ip address to this list to send telemetry
        p = Process(target = individualguicomm, args=(queue, connection, )) 
        # created subprocess handling each induvidual client
        p.start()
    # again, socket will not be closed. could be troubling

def individualguicomm(queue, connection):
    RECVBUFSIZE = 4096 # maximum bytes receiving each time, probably need to adjust this.
    while True:
            data = connection.recv(RECVBUFSIZE)
            if data: # data is non-zero means there is data. btw 0 is False and everything else is True, iirc
                queue.put(data) # put data to guirecvqueue for it to be processed
                # if two or more gui are connected, as of right now the command sent from
                # different gui will be fed to the same queue (guirecvqueue).
                # Supposedly queue are process safe, so there shouldn't be corruption
                # from simutaneous queue.put(x) from two different processes
    # socket not closed.
    
# subprocess might linger even after main exits.
# rebooting would solve it but probably better to return those subprocess at some time
# maybe a list keeping track of subprocesses to kill before main exit?
