import struct
import serial
import zlib
from multiprocessing import Queue, Process
import calculate
import guicomm

'Configuration'
FRAMELEN = 33 # number of bytes transmitted thru serial for each set of data
# please make sure it matches size of SensorData + starting char + checksum
# i.e. sizeof(sdata) + 5 in arduino code 
FRAMESTARTCHAR1 = 60 # '<'
SENSORTTY = '/dev/ttyACM0'
MESGPATTERN = '<Lffffff' 
# layout of SensorData in arduino
# < in here represent little endian, each letter corresponds to different types of data
# h for signed int and H for unsigned int etc (in arduino int is 2 bytes)
# see link below for reference of format character
# https://docs.python.org/2/library/struct.html#format-characters
# note that arduino use non-standard size for data type, see below
# https://robotresearchlab.com/2016/11/14/variable-data-types/

ser = serial.Serial(SENSORTTY,baudrate = 9600, timeout = None, bytesize = serial.EIGHTBITS)
count = FRAMELEN
serbuf = bytes() # buffer/placeholder for serial data input
guisendqueue = Queue() # for transferring data to subprocess that handle udp comm
guirecvqueue = Queue() # for subprocess handling tcp comm

# frame layout (FRAMELEN bytes):
# index: |  0  | 1 to FRAMELEN-5 | FRAMELEN-4 to FRAMELEN-1 |
#        | '<' |     PAYLOAD     |    CHECKSUM (4 bytes)    |  

def initialize_gui_communication():
    p = Process( target=guicomm.initguisend, args=(guisendqueue,)) # "spun off" subprocess to handle udp comm
    q = Process( target=guicomm.initguicomm, args=(guirecvqueue,)) # ditto but for tcp
    p.start()
    q.start()

def process_data():
    global serbuf
    # list[x:y] is subarray/sublist from index x to y-1
    # e.g. arr = [a,b,c,d,e], then arr[1:4] == [b,c,d]
    #             0 1 2 3 4   
    mesg = serbuf[1:(FRAMELEN-4)] # mesg discard starting char and checksum i.e. get payload only
    p = Process( target=calculate.calculate, args=((struct.unpack(MESGPATTERN,mesg)),guisendqueue,) ) # subprocess to calculate 
    p.start()
    return

def read_in(i): # i = number of bytes to take in from serial stream to serbuf
    global serbuf
    assert (i != 0), "Infinite loop from not reading in new serial input"
    assert (i <= FRAMELEN), "Out of range of defined frame"
    if i == FRAMELEN: # replace the whole buffer by taking in full length
        serbuf = ser.read(i) 
    else:
        serbuf = serbuf[i:] + ser.read(i) # discard first i bytes and concat i bytes from serial stream
        # e.g. serbuf = [a,b,c,d,e], i = 3, serial stream = [f,g,h,i,j]
        # serbuf = [d,e] + [f,g,h] == [d,e,f,g,h]
    return

def frame_validated():
    global serbuf
    mesg = serbuf[1:(FRAMELEN-4)] # mesg is the payload
    crc = serbuf[(FRAMELEN-4):] # last 4 bytes are checksum
    return ((zlib.crc32(mesg)).to_bytes(4,byteorder="little") == crc) 
    #        ^--------------^ to calculate checksum
    # the calculated checksum is converted to 'bytes' object 
    # in little endian to compare against checksum received

if __name__ == "__main__":
    initialize_gui_communication()
    while True:
        while ser.in_waiting < FRAMELEN: # block/wait for enough bytes to read in
                continue
        read_in(count)
        if serbuf[0] == FRAMESTARTCHAR1: # when the first character is indeed the starting character
            if frame_validated(): # when the data is validated against the crc32 at the last 4 bytes
                process_data()
                count=FRAMELEN # replace buffer with next full length read in
                continue
        count = 1 # first character is not starting character, discard
        # if for some reason '<' is not the starting character in buffer
        # 
        for b in serbuf[1:]: # find next start char, if any
            if b == FRAMESTARTCHAR1:
                break
            count += 1
