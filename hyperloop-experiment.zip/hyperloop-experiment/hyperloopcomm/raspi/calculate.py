import multiprocessing
import guicomm

def calculate(arr_to_be_calculated, queue_to_be_sent):
    result = []

    # To do: implement calculations

    # A class or dictionary instead of list/arr may help organizing & maintenance
    for item in arr_to_be_calculated:
        result.append(item) 
    
    queue_to_be_sent.put(result)
