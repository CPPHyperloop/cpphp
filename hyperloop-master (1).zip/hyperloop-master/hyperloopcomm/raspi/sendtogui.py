import struct
import socket
import sys

SERVERIP = 'localhost' #'192.168.x.x'
PORT = 10000
PACKPATTERN = '<LhHcff'

def send(arr):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_address = (SERVERIP, PORT)
    try:
        sock.sendto(struct.pack(PACKPATTERN, *arr),server_address)
    finally:
        sock.close()