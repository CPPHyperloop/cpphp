import multiprocessing
import sendtogui

def calculate(arr):
    result = []
    print(arr)
    # To do: implement calculations
    for item in arr:
        result.append(item)
    print(result)
    p = multiprocessing.Process(target=sendtogui.send, args=(result,))
    p.start()