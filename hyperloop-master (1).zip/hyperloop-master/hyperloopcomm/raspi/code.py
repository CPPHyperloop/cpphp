import struct
import serial
import zlib
import multiprocessing
import calculate

'Configuration'
FRAMELEN = 22
FRAMESTARTCHAR = 60
SENSORTTY = '/dev/ttyACM0'
MESGPATTERN = '<LhHcff'

ser = serial.Serial(SENSORTTY,baudrate = 9600, timeout = None, bytesize = serial.EIGHTBITS)
count = FRAMELEN
serbuf = bytes()

def process_data():
    global serbuf
    mesg = serbuf[1:(FRAMELEN-4)]
    p = multiprocessing.Process( target=calculate.calculate, args=((struct.unpack(MESGPATTERN,mesg)),) )
    p.start()
    return

def read_in(i):
    global serbuf
    assert (i != 0), "Infinite loop from not reading in new serial input"
    assert (i <= FRAMELEN), "Out of range of defined frame"
    if i == FRAMELEN:
        serbuf = ser.read(i)
    else:
        serbuf = serbuf[i:] + ser.read(i)
    return

def frame_validated():
    global serbuf
    mesg = serbuf[1:(FRAMELEN-4)]
    crc = serbuf[(FRAMELEN-4):]
    return ((zlib.crc32(mesg)).to_bytes(4,byteorder="little") == crc)

if __name__ == "__main__":
    while True:
        while ser.in_waiting < FRAMELEN:
                continue
        read_in(count)
        if serbuf[0] == FRAMESTARTCHAR: # when the first character is indeed the starting character
            if frame_validated(): # when the data is validated against the crc32 at the last 4 bytes
                process_data()
                count=FRAMELEN
                continue
        count = 1
        for b in serbuf[1:]: # find next start char, if any
            if b == FRAMESTARTCHAR:
                break
            count += 1