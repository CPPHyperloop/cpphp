import struct
import socket
import sys

PACKPATTERN = '<LhHcfffff'
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_address = ('192.168.1.191', 10000)
sock.bind(server_address)

while True:
    print('\nwaiting to receive message')
    data, address = sock.recvfrom(4096)

    print('received {} bytes from {}'.format(
        len(data), address))
    print(struct.unpack(PACKPATTERN,data))